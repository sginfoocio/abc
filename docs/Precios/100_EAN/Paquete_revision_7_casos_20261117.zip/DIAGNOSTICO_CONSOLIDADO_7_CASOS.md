# Diagnóstico consolidado de siete casos

Fuente: revision-7-casos.json, exportación SQLite de solo lectura realizada el 17/11/2026 a las 22:45:34 UTC (23:45:34 Madrid). Esta revisión no realiza HTTP ni modifica producción. El alcance de negocio sigue siendo 100 EAN y 14 competidores; los siete casos son una muestra, no una validación de 1.400 pares.

## Conclusión

Hay causas concretas de configuración, interpretación de referencias y vinculación de ofertas. No corresponde clasificar estos rechazos como productos inexistentes. Los datos rechazados sí se conservaron en varios discovery_index.facts, aunque monitor_jobs.sample estuviera vacío: futuras revisiones deben exportar ambos, con sus fechas, antes de pedir nuevas consultas.

| Solicitud manual | Tienda / EAN | Hallazgo y grado de evidencia | Próxima corrección |
|---|---|---|---|
| 1 | Optical H / 0805289126577 | Confirmado: muestra del 17/11 con EAN exacto, 109,85 EUR, available, IVA incluido, sin ambigüedad y sin mercado explícito. Configuración exportada ES y verificada después del guardado web; el monitor conserva el gap anterior market_currency. | Reevaluación local auditada de la muestra con las políticas actuales, validando identidad y vigencia y conservando la fecha original. No HTTP nuevo ni duplicación de oferta. |
| 8 | Edel / 0889652650838 | Rechazo actual de URL de variante. Código revisado: el extractor puede añadir selectedSize y el monitor rechaza desigualdad literal. Los facts disponibles son del 12/11 y registran Product Id 2352387; no son la respuesta del 17/11. La interfaz no permite diagnosticar la URL porque continúa verificada. | Resolver identidad de URL base/opción observada sin aceptar variantes contradictorias. Permitir diagnóstico gobernado de una ficha aceptada cuya lectura falla, conservando trazas antes del rechazo. Hace falta respuesta actual para confirmar completamente este caso. |
| 10 | Amevista JOEY / 0889214625625 | Rechazo actual FT1301 + JOEY02. No hay facts actuales; previous_sample es del 10/11, con 217,50 EUR, EAN exacto y available: histórico, no oferta vigente. Diagnóstico 6 rechazado con PilotError, sin HTTP ni artefacto. | Resolver el impedimento del diagnóstico y conservar el motivo preciso de PilotError; no afirmar todavía qué condición del piloto lo origina. Contrastar JOEY como descriptor en respuesta actual; no reutilizar la muestra caducada como actual. |
| 54 | Amevista Gucci / 0889652494821 | Confirmado con facts del 17/11 y captura 7: GG1660S-001 en name/productGroupID; model=Logotipo Gg; variante por GTIN normalizado y Offer de 188,50 EUR en stock. El clasificador acumula LOGOTIPOGG como segundo modelo. | Separar descriptor comercial y referencia de fabricante, con asociación por marca, modelo/color, grupo y variante. No ignorar otro código real contradictorio. |
| 75 | Visual-Click / 8056262142585 | Captura 8: nombre MU 54YS ZVN20F 80, producto y Offer con mismo SKU compuesto, 331 EUR e InStock. Facts de la lectura: color inferido ZVN20F80, offer_binding_unresolved=true y falta de oferta que coincida con la URL base. | Dos correcciones independientes: separar referencia y sufijo sin inventar significado de 80; resolver Offer ?variant=48783648653611 del mismo Product/SKU. El prefijo numérico de un SKU compuesto no equivale automáticamente a GTIN publicado. |
| 182 | Domanci / 8056262412367 | Confirmado con facts del 17/11 y captura 9: título MU A51S 5AK20P 75; GTIN 8056262412367 idéntico en Product y Offer; 305,50 EUR e InStock. SKU/MPN 0MU_A51S5AK20P7514 produce falsos modelos 0MU y colores concatenados. | Interpretación contextual del código compuesto apoyada en título, referencia y GTIN. No tratar el código completo como color ni el prefijo 0MU como otro modelo; no borrar contradicciones reales ni inventar medidas. |
| 196 | Bassol / 0805289126577 | Facts del 17/11: título RB2140 WAYFARER 901 50; identificador 805289126577; Offer de variante conocido pero no vinculado, precio ausente y stock unknown. Captura 10 rechazada por tamaño con recibo 3772; sin HTML retenido. | Vinculación Product/Offer/variante y tratamiento documentado del identificador. Resolver el límite de captura de forma acotada antes de otro intento explícito; no ejecutar bucles. |

## Detalles importantes

### Optical H

El JSON confirma sales_market=ES, market_verified=1 y la procedencia de la confirmación de Ruben. La muestra conserva configured_tax_policy=unknown, mientras que la configuración actual registra included; incluye IVA y evidencia fiscal de negocio. Una reevaluación legítima debe aplicar y auditar la política actual, en vez de ignorar silenciosamente los controles de cambios de configuración. El precio y el stock siguen fechados el 17/11 a las 17:09:04 UTC; cambiar configuración no renueva la muestra ni su caducidad. El guardado web no actualizó por sí solo la oferta.

### Amevista y Visual-Click: configuración comercial

Ambas aparecen con sales_market vacío y market_verified=0 en la exportación. En los facts completos de Gucci sí consta mercado ES explícito, por lo que no debe confundirse una configuración de respaldo ausente con falta de mercado en esa lectura. La captura sanitizada es parcial y excluye campos de entrega: su ausencia en el artefacto no demuestra ausencia en el HTML original. Para Visual-Click no hay mercado explícito en los facts y la configuración de respaldo está pendiente; corregir solamente identidad/variante puede dejar una segunda exclusión comercial. La decisión de negocio de IVA incluido se conserva aunque el tax_policy configurable de Visual-Click figure unknown.

### Bassol

La ruta /nl-nl/ no permite por sí sola decidir mercado. Existe configuración ES verificada con evidencia comercial anotada el 13/11; no debe sustituirse por una deducción a partir del idioma. La captura actual usa 901-50, distinta de los antiguos intentos sobre 901-32-50: no mezclar sus recibos ni variantes. El resultado no demuestra producto inexistente, falta de stock o un bloqueo antibot. El recibo 3772 registra error: ConnectorError; no se le atribuye un HTTP 200 no registrado. La etapa candidate_and_deferrals del resultado no describe adecuadamente el fallo por tamaño posterior al intento de lectura.

### Variantes y calibre

El calibre no cambia el precio del mismo modelo/color. Deben separarse precio común, EAN y disponibilidad de la variante. No trasladar stock, no convertir un SKU compuesto en GTIN mediante recorte indiscriminado, no aceptar otro color y no suprimir todos los parámetros variant/selectedSize como solución al rechazo de URL.

## Integridad de las capturas

Los tres artefactos se extrajeron directamente del JSON de SQLite y se guardaron como archivos separados sin etiquetas añadidas por el navegador. Su longitud y SHA-256 coinciden con los recibos exportados:

| Diagnóstico | Tienda | Bytes | SHA-256 |
|---|---|---:|---|
| 7 | Amevista | 936 | cf239f7c16c29e5d05743eef881dd34e349a76ecfb73948574aea5b0f5ffa533 |
| 8 | Visual-Click | 596 | f2ba1ef3f70781330ae9d57f5052484867db919099262092467a4273a52e2397 |
| 9 | Domanci | 653 | ca16dece3bb302298932d35dfc049795c888dbb8b4adae98f8dbd8720d3446fa |

Cada una tiene un recibo HTTP 200 (3768, 3769 y 3770), URL solicitada/final iguales y sin redirecciones. Son sanitizado_parcial_jsonld, no los HTML brutos completos. JOEY y Bassol no tienen artefacto de esta operación. No existe solicitud diagnóstica actual para Edel.

## Orden de trabajo propuesto

1. Conservar este paquete y reproducir los fallos sobre los facts y los tres artefactos reales, distinguiendo las fechas históricas.
2. Corregir referencias/alias de Gucci y códigos compuestos de Domanci; resolver los dos fallos de Visual-Click y su configuración comercial pendiente de acuerdo con la confirmación del responsable.
3. Incorporar una reevaluación local auditada de muestras vigentes para Optical H, sin renovar fechas ni generar HTTP o duplicados.
4. Completar diagnóstico de fichas verificadas con fallo, motivo de PilotError y tratamiento acotado del límite de Bassol. Cualquier nuevo HTTP debe usar el flujo gobernado y los presupuestos existentes.
5. Previsualizar qué solicitudes históricas realmente pasan las nuevas reglas; aplicar primero una por mecanismo y después las elegibles, conservando recibos, decisiones y estado anterior. No reactivar ciegamente todos los errores.

No se ha corregido código del repositorio, preparado una nueva PR, recuperado otra vez la cola ni importado precios en esta revisión offline. No se extrapolan los resultados de siete casos a todos los EAN de las tiendas.
