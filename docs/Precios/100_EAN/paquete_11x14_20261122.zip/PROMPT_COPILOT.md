Continúa en la misma PR #145 y en su rama de recuperación, coordinándote con el trabajo ya iniciado. No abras otra PR ni mezcles cambios nuevos de MySQL/PrestaShop. No hagas merge ni despliegue desde este encargo.

OBJETIVO
Recuperar la cobertura válida alcanzada (93/100 comunicados por Rubén, que debes contrastar con la instantánea histórica) y acercarnos a 100/100 EAN con ofertas actuales entre los 14 competidores. Cada gafa puede encontrarse por EAN o por marca+modelo completo+color con evidencia suficiente. Cuantas más tiendas por gafa, mejor; no inventes ofertas para llegar a una cifra.

PAQUETE DE ENTRADA
- C:/Users/RubenSG/.codex/.chatgpt-projects/g-p-6abf5a8fe83c81919bad6b6dc0b99cf8/outputs/busqueda_11_20261122/matriz_11x14.json
- C:/Users/RubenSG/.codex/.chatgpt-projects/g-p-6abf5a8fe83c81919bad6b6dc0b99cf8/outputs/busqueda_11_20261122/RUTAS_Y_CORRECCIONES.md
Estos archivos están fuera del checkout: léelos desde esas rutas o copia únicamente los artefactos necesarios a la carpeta de evidencias de la misma PR, conservando procedencia. Si tu equipo no accede a ellos, solicita el paquete concreto una sola vez; no finjas haberlo leído.

La matriz tiene 154 pares únicos: 94 fichas/páginas de variantes localizadas, 12 candidatas solo documentales, 2 pistas de catálogo, 1 redirección inválida y 45 sin ruta localizada en índice. No acredita ofertas actuales ni EAN exacto en todos los hallazgos. Algunas fuentes son extranjeras o antiguas. El JSON anterior de 17 rutas es antecedente; la matriz nueva es la entrega ampliada.

LOS ONCE EAN
- 0843023181451 — Cartier CT0550S 001
- 8056597886932 — Miu Miu MU 52YS 7OE01T
- 8056262407691 — Miu Miu MU A06S 14L09Z
- 8056597875349 — Prada PR 27ZS 16K08Z
- 0805289126591 — Ray-Ban RB2140 901/58
- 0889652429687 — Saint Laurent SL 596 DUNE 003
- 0889214625984 — Tom Ford FT1310 01A
- 0889214669742 — Tom Ford FT1360 30A
- 0889214042422 — Tom Ford FT5634-B 001
- 0889214586650 — Tom Ford FT6058-B 001
- 0889214599834 — Tom Ford FT6082-B 051

REGLAS DE NEGOCIO
El calibre no cambia el precio del mismo modelo y color: no bloquees el precio común solo por carecer de talla en el catálogo. Mantén separadas la atribución del precio al modelo/color, la identidad exacta del EAN y la disponibilidad de cada variante. No quites sufijos B, letras de A06S ni partes del color; 901/58 es color, no calibre58, y no equivale a 901. DUNE y DUNE OPT son referencias distintas.
Comparación de competidores: mercado español, EUR, IVA incluido, con vigencia y disponibilidad conforme a la política real. La política declarada de los 14 competidores no debe ocultar una respuesta concreta en otra moneda o país. Odoo conserva su referencia vigente y la integración MySQL de PrestaShop sigue separada: no recalcules ni vuelvas a validar aquí los 100 precios propios.

TRABAJO CONCRETO
1. Revisa el diff actual y aprovecha correcciones ya hechas. Obtén una línea base actual consistente del dashboard y del inventario mediante el mismo instante/política. Explica la diferencia 73/70 y el máximo histórico93 por EAN: precio propio ausente, expiración, rechazo de identidad, disponibilidad, mercado, cola o filtros. No presentes una instantánea vieja como actual.
2. Cruza los 154 pares con las rutas, aprobaciones originales, solicitudes existentes, muestras/recibos vigentes y estados vivos. No dupliques solicitudes ni pidas confirmar otra vez lo que tiene aprobación válida y trazable. No inventes aprobación ausente ni resuelvas contradicciones reales por fuerza.
3. Implementa correcciones reutilizables por competidor a partir del informe. Prioridades: aliases B/V de Visio respaldados por GTIN; nombres y rutas comerciales reales de Óptima/Amevista; códigos UPC normalizados; rechazo de redirecciones a catálogo en Edel; selección de variantes en páginas compartidas; disponibilidad y contexto de mercado acreditados. No hagas una lista de URLs sin conectarla al localizador y al monitor existentes.
4. El caso MU A06S de Edel redirigió a categoría: descubre la ficha correcta si existe mediante fuentes permitidas, sin extraer de otros productos. La lista de EAN de RB2140 debe vincularse con sus variantes, sin stock cruzado. Los códigos internos BARCODE de Mia Burton se distinguen de UPC/EAN sin declarar equivalencias falsas. FT5634 en Óptima tiene importes contradictorios: no elijas el más barato por conveniencia.
5. Usa primero capturas ya guardadas y reevalúa offline cuando basten. Para evidencia insuficiente, prepara la comprobación/captura gobernada del par exacto con el trabajador existente. Antes de enviar HTTP, revalida aprobación/permisos, robots, presupuesto compartido, Retry-After, próxima fecha, lease y recibos. Respeta bloqueos/429/CAPTCHA y no cambies de país para eludirlos. No montes un scraper paralelo ni uses este JSON como cola de 232 URLs.
6. Reutiliza la lectura vigente; si hace falta otra, una sola solicitud lógica por par/URL/versión de aprobación, recuperable e idempotente ante doble clic, carrera con la vigilancia o reinicio. Una reserva de red con resultado incierto se reconcilia antes de reintentar. No borres locks, historial, intentos o recibos; no pauses la vigilancia ni amplíes límites para terminar antes.
7. Donde no exista ruta, busca también por modelo+color y enlaces de catálogo/sitemaps/búsqueda interna solo cuando estén permitidos. Sin resultado indexado no significa producto inexistente. No infieras una URL local a partir de un slug extranjero como si ya estuviera verificada.
8. Demuestra cada arreglo con el replay de evidencia real trazable disponible, indicando edad y límites. No hagas pasar HTML sintético por captura original. Guarda solo evidencia sanitizada con URL solicitada/final, contexto, fecha y huella según el mecanismo existente.

VALIDACIÓN MÍNIMA SUFICIENTE
Selecciona regresiones por funciones modificadas: normalización de códigos, modelo/color, variante/precio común/stock, redirecciones a categoría, recuperación aprobada e idempotencia en concurrencia/reinicio. Reutiliza suites y fixtures existentes. Evita sleeps, red, estrés/benchmarks y toda la carpeta tests si el diff no lo justifica. No reduzcas permisos ni elimines pruebas para lograr verde. Si un control requerido exige cobertura adicional, explica el motivo concreto y corrige la selección del workflow sin falsear el SHA/base/head. Docker: build/imports y smoke offline mínimo que cargue el artefacto y ejecute los mecanismos afectados como UID/GID1037:100, conservando privacidad. No repitas la suite por cambios exclusivamente documentales salvo requisito real del workflow. Publica resultados del SHA exacto y su duración; no atribuyas checks antiguos al HEAD nuevo.

ENTREGA
Código y regresiones en la misma PR; matriz reproducible de los 154 pares y su relación con los 1.400 del manifiesto intacto; lista concreta de rutas incorporadas, descartadas y pendientes con motivo. Separa candidata, ficha validada, lectura actual y oferta comparable. Informa qué se ejecutó realmente en producción y qué quedó preparado; no declares recuperación por una modificación documental. No escribas en Odoo/PrestaShop, no mezcles MySQL, no detengas la vigilancia. No cierres con otra actualización de informe si aún puedes implementar o reproducir el bloqueo con la evidencia disponible.

