# Validación real de #133 — 16/11/2026

Runtime: e2eb0392e0a024bc226af0c87f0d5695aa25af68. Par diagnóstico: EAN 0805289126577.

El operador restringió el archivo SQLite de 0644 a 0600. Las capturas posteriores superaron el control de almacenamiento. No se verificaron copias de seguridad ni privacidad física del volumen.

## Resultados

- Optical H, solicitud 2: capturada, HTTP 200. JSON-LD publica gtin 805289126577 (normalizable al EAN solicitado), nombre RB2140 901 50 22, precio 109,85 EUR y InStock. Offer contiene URL con variant=57108062601561. No se aceptó identidad ni se modificó oferta durante el diagnóstico.
- Visual-Click, solicitud 3: capturada, HTTP 200. Publica RB2140 901/32 50, SKU cuyo prefijo es 0805289183051 y Offer con ese mismo SKU. EAN distinto del solicitado: esta candidata no acredita el par. Precio publicado 124 EUR, InStock; no transferir estos datos al EAN solicitado.
- Mia Burton, solicitud 4: capturada, HTTP 200. Tres Offer de 174 EUR, InStock, medidas 50/22, 54/18 y 52/22; sin EAN en la evidencia conservada. La URL termina en 901-58. No resolver la identidad o el stock individual únicamente por URL o por igualdad de precio. El calibre no cambia el precio del mismo modelo/color.
- Bassol, solicitud 1: rechazo previo a HTTP por permisos. Una nueva solicitud desde el formulario devuelve el mismo ID rechazado. El código usa INSERT OR IGNORE y un índice único para todos los estados salvo expired; la expiración automática solo afecta solicitudes con artefacto. No existe reintento soportado de este rechazo. No se alteraron filas ni se escogió otra URL para evadir la deduplicación.
- Cierre posterior 529/comprobación 2795: preview no elegible por petición o reserva posterior al inicio, incluso sin EAN. No se aplicó recuperación.

## Evidencias y límites

Los TSV contienen los resultados completos visibles: URLs solicitada/final/canonical, hashes, recibos y expiración. Los HTML son reconstrucciones sanitizadas parciales de JSON-LD, no respuestas HTML originales. Se conservaron 612, 620 y 1276 bytes respectivamente. Recibos únicos de las tres capturas: 3109, 3110, 3111, 3112 y 3113 (cinco peticiones contabilizadas; no se atribuyen todas a fichas sin clasificación adicional).

La continuidad permaneció activa con el manifiesto de 100 EAN y 14 competidores. No se aceptaron revisiones ni se cambiaron ofertas, plazos, permisos de acceso comercial o presupuestos mediante estas acciones. No se realizó sincronización manual Vytria/Odoo.

Pendiente: reintento explícito y auditado del rechazo Bassol sin HTTP previo, conservando el intento original y revalidando permisos, robots, presupuesto y privacidad. No usar SQL directo para forzar estados.
